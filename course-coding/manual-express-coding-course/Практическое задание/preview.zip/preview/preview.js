/* Preview
========================================================*/
;(function ($) {

	var images = ['preview/page01.jpg', 'preview/page02.jpg', 'preview/page03.jpg', 'preview/page04.jpg', 'preview/page05.jpg', 'preview/page06.jpg', 'preview/page07.jpg', 'preview/page08.jpg'];
	var image = 0;

	if (typeof $.cookie('first-load-flag') === 'undefined') {
		$.cookie('vertical-offset', 0);
		$.cookie('horizontal-offset', 0);
		$.cookie('option-tools', false);
		$.cookie('option-hide', false);
		$.cookie('option-1', false);
		$.cookie('option-2', false);
		$.cookie('option-3', false);
		$.cookie('option-4', false);
		$.cookie('first-load-flag', true);
	}

	var step = 1;
	var v_off = parseInt($.cookie('vertical-offset'));
	var h_off = parseInt($.cookie('horizontal-offset'));

	if ($.cookie('option-tools') == 'true') { var option_tools_flag = true }
	else { var option_tools_flag = false }

	if ($.cookie('option-hide') == 'true') { var option_hide_flag = true }
	else { var option_hide_flag = false }

	if ($.cookie('option-1') == 'true') { var option_1_flag = true }
	else { var option_1_flag = false }

	if ($.cookie('option-2') == 'true') { var option_2_flag = true }
	else { var option_2_flag = false }

	if ($.cookie('option-3') == 'true') { var option_3_flag = true }
	else { var option_3_flag = false }

	if ($.cookie('option-4') == 'true') { var option_4_flag = true }
	else { var option_4_flag = false }

	$(document).ready(function () {

		$('body').addClass('preview');
		$('.preview__substrate').attr('style', 'background-image: url(' + images[image] + '); margin-top: ' + v_off + 'px; margin-left: ' + h_off + 'px;');

		if (option_tools_flag) {
			$('.option-tools').toggleClass('toggle');
		}

		if (option_hide_flag) {
			$('.preview__statusbar').toggleClass('preview__statusbar--display-none')
			$('.option-hide').toggleClass('toggle');
		}

		if (option_1_flag) {
			$('body').toggleClass('preview--substrate-display')
			$('.option-1').toggleClass('toggle');
		}

		if (option_2_flag) {
			$('body').toggleClass('preview--substrate-contrast')
			$('.option-2').toggleClass('toggle');
		}

		if (option_3_flag) {
			$('body').toggleClass('preview--substrate-full-opacity')
			$('.option-3').toggleClass('toggle');
		}

		if (option_4_flag) {
			$('body').toggleClass('preview--substrate-fill')
			$('.option-4').toggleClass('toggle');
		}

		$(document).on("keydown", function(event) {
			var current = event.which;

			console.log(current);
	
			switch (current) {

				case 81:
					option_tools_flag = !option_tools_flag;
					$.cookie('option-tools', option_tools_flag);
					$('.option-tools').toggleClass('toggle');
					break;

				case 87:
					option_hide_flag = !option_hide_flag;
					$.cookie('option-hide', option_hide_flag);
					$('.preview__statusbar').toggleClass('preview__statusbar--display-none')
					break;

				case 49:
					if(option_tools_flag) {
						option_1_flag = !option_1_flag;
						$.cookie('option-1', option_1_flag);
						$('body').toggleClass('preview--substrate-display')
						$('.option-1').toggleClass('toggle');
					}
					break;

				case 50:
					if(option_tools_flag) {
						option_2_flag = !option_2_flag;
						$.cookie('option-2', option_2_flag);
						$('body').toggleClass('preview--substrate-contrast')
						$('.option-2').toggleClass('toggle');
					}
					break;

				case 51:
					if(option_tools_flag) {
						option_3_flag = !option_3_flag;
						$.cookie('option-3', option_3_flag);
						$('body').toggleClass('preview--substrate-full-opacity')
						$('.option-3').toggleClass('toggle');
					}
					break;

				case 52:
					if(option_tools_flag) {
						option_4_flag = !option_4_flag;
						$.cookie('option-4', option_4_flag);
						$('body').toggleClass('preview--substrate-fill')
						$('.option-4').toggleClass('toggle');
					}
					break;
	
				case 38:
					if(option_tools_flag) {
						v_off = v_off - step;
						$('.preview__substrate').css('margin-top', v_off);
						$.cookie('vertical-offset', v_off);

						console.log(step);
						return false;
					}
					break;

				case 40:
					if(option_tools_flag) {
						v_off = v_off + step;
						$('.preview__substrate').css('margin-top', v_off);
						$.cookie('vertical-offset', v_off);
						return false;
					}
					break;

				case 37:
					if(option_tools_flag) {
						h_off = h_off - step;
						$('.preview__substrate').css('margin-left', h_off);
						$.cookie('horizontal-offset', h_off);
						return false;
					}
					break;

				case 39:
					if(option_tools_flag) {
						h_off = h_off + step;
						$('.preview__substrate').css('margin-left', h_off);
						$.cookie('horizontal-offset', h_off);
						return false;
					}
					break;

				case 17:
					if(option_tools_flag) {
						step = 10;
					}
					break;

			}

		});

		$(document).on("keyup", function(event) {
			var current = event.which;
	
			switch (current) {

				case 17:
					step = 1;
					break;

			}

		});

	});

})(jQuery);